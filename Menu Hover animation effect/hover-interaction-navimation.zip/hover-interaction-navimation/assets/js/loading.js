$(document).ready(function () {
    $(".loading").show()
    setTimeout(() => {
        $(".loading").hide()
    }, 1800);
});